﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;

namespace Crystal
{
	public partial class App : Application
	{
	}
}
